  <!-- link -->
  <a href="/admin/home" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-tachometer text-xs mr-2"></i>                
        Dashboard
      </a>
      <!-- end link -->

      <!-- link -->
      <a href="/admin/log" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-history text-xs mr-2"></i>
        Activity Log
      </a>

      <!-- link -->
      <a href="/admin/usermanagement" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
        <i class="fad fa-cog text-xs mr-2"></i>
        User Management
      </a>