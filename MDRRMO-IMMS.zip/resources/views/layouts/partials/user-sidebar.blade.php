<!-- link -->
<a href="/user/home" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
<i class="fad fa-tachometer text-xs mr-2"></i>                
Dashboard
</a>
<!-- end link -->

<!-- link -->
<a href="/user/equipment" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
<i class="fad fa-clipboard text-xs mr-2"></i>
Equipment
</a>

<!-- link -->
<a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
<i class="fad fa-list text-xs mr-2"></i>
Barrowed
</a>

<!-- link -->
<a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
<i class="fad fa-undo text-xs mr-2"></i>
Returned
</a>

<!-- link -->
<a href="#" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
<i class="fad fa-recycle text-xs mr-2"></i>
Damaged
</a>

<!-- link -->
<a href="/user/log" class="mb-3 capitalize font-medium text-sm hover:text-teal-600 transition ease-in-out duration-500">
<i class="fad fa-history text-xs mr-2"></i>
Activity Log
</a>