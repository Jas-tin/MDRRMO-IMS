<div class="container">
    <div class="flex text-center gap-5 inline-block items-center justify-center">
        <img src="{{asset('img/mdrrmo-bulan.png')}}" alt="{{ config('app.name') }}" class="max-h-28 float-end rounded-full">
        <h1 class="text-lg font-bold text-foreground mb-6 text-left">MDRRMO <br>Inventory and Monitoring<br> Management System</h1>
    </div>
</div>