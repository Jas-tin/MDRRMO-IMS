<div class="container">
    <div class="flex text-center gap-5 inline-block items-center justify-center">
        <img src="<?php echo e(asset('img/mdrrmo-bulan.png')); ?>" alt="<?php echo e(config('app.name')); ?>" class="max-h-28 float-end rounded-full">
        <h1 class="text-lg font-bold text-foreground mb-6 text-left">MDRRMO <br>Inventory and Monitoring<br> Management System</h1>
    </div>
</div><?php /**PATH C:\Users\Jas\Downloads\New folder\MDRRMO-IMMS\resources\views/components/logo.blade.php ENDPATH**/ ?>